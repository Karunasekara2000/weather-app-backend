package com.weather_app_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
